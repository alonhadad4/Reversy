//
// Created by feees on 28/12/17.
//

#include "CloseCommand.h"

CloseCommand::CloseCommand(){

}

void CloseCommand::execute(vector<string> args , Server * server) {
    server->closeGame();
}