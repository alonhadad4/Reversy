//
// Created by feees on 28/12/17.
//

#include "Command.h"
#include "Server.h"


class JoinGameCommand: public Command {
public:
    JoinGameCommand();
    ~JoinGameCommand();
    void execute(vector<string> args , Server * server);
};
