//
// Created by feees on 28/12/17.
//

#include "Command.h"
#include "Server.h"


class PlayCommand: public Command {
public:
    PlayCommand();
    ~PlayCommand();
    void execute(vector<string> args , Server * server);
};
