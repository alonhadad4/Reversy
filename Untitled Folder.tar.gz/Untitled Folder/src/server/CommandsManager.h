//
// Created by feees on 28/12/17.
//

#ifndef UNTITLED5_COMMANDSMANAGER_H
#define UNTITLED5_COMMANDSMANAGER_H
#include <map>
#include "Command.h"


class CommandsManager {
public:
    CommandsManager();
    ~CommandsManager();
    void executeCommand(string command, vector<string> args , Server * server);
private:
    map<string,Command *> commandsMap;
};


#endif //UNTITLED5_COMMANDSMANAGER_H
