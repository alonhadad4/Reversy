//
// Created by feees on 28/12/17.
//

#include "StartCommand.h"

StartCommand:: StartCommand() {
}

void StartCommand::execute(vector<string> args , Server * server) {
    server->startNewGame(args[0]);
}