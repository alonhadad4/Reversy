//
// Created by feees on 28/12/17.
//

#ifndef UNTITLED5_COMMAND_H
#define UNTITLED5_COMMAND_H

#include <vector>
#include <string>
#include "Server.h"

using namespace std;


class Command {

public:
    virtual void execute(vector<string> args , Server * server) = 0;
    // virtual ~Command() = 0;
};


#endif //UNTITLED5_COMMAND_H
