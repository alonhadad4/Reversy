//
// Created by feees on 28/12/17.
//

#include "JoinGameCommand.h"

JoinGameCommand:: JoinGameCommand() {

}

void JoinGameCommand::execute(vector<string> args , Server * server) {
    server->joinGame(args[0]);
}