//
// Created by feees on 28/12/17.
//

#include "PlayCommand.h"

PlayCommand:: PlayCommand() {

}

void PlayCommand::execute(vector<string> args , Server * server) {
    // translating args to ints
    int i = 0;
    int j = 0;
    server->executeMove(i , j);
}