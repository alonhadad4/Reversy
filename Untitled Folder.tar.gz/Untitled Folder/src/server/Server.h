#include <string>
#include <map>

#ifndef UNTITLED5_SERVER_H
#define UNTITLED5_SERVER_H

using namespace std;

class Server {
public:
    Server(int port);
	/**
	* the function activates the server and waits for clients.
	* when clients are connected, it calls the game loop.
	*/
    void start();
	/**
	* the function closes the server.
	*/
    void stop();
    void startNewGame(string name);

    void showGameList();

    void closeGame();

    void joinGame(string name);

    //this function will execute a move
    void executeMove(int i , int j);


private:
    int port;
    int serverSocket;
    int cp1;
    int cp2;
    map <string, pthread_t *> listOfGames;
    static void * gameLoop(void *t);
	/**
	* the function runs the game for two servers, reading and writing to them.
	*/
    void startGameLoop();
	/**
	* the function sends a player with client socket cp his sign in the game.
	*/
    void sendSign(int sign,int cp);


};

#endif //UNTITLED5_COMMAND_H