//
// Created by feees on 28/12/17.
//

#include "Command.h"
#include "Server.h"


class CloseCommand: public Command {
public:
    CloseCommand();
    ~CloseCommand();
    void execute(vector<string> args , Server * server);
};
