/*
class Client {
public:
    Client(const char *ServerIP,int serverPort);
    void connectToServer();
    char* sendMove(int arg1,char op, int arg2);
    char* readMove();
private:
    const char *serverIP;
    int serverPort;
    int clientSocket;
};
*/