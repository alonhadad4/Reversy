//
// Created by ori on 23/11/17.
//
#include "gtest/gtest.h"
#include <iostream>
using namespace std;
#include "../src/Board.h"
#include "../src/BoardDisplayer.h"
#include "../src/ConsoleDisplay.h"
#include "../src/Player.h"
#include "../src/HumanConsolePlayer.h"
#include "../src/GameRules.h"
#include "../src/BasicGameRules.h"

TEST(TestSomething, Test1) {
    EXPECT_EQ(1,1);
}

